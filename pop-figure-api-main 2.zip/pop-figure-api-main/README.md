# Pop Figure API

A small REST API for cataloging Pop figures using the fields shown in the reference screenshots.

## Run locally

```bash
npm install
cp .env.example .env
npm start
```

Replace the placeholder values in `.env` with your rotated MongoDB password and
GitHub token. The `.env` file is ignored by Git and must never be committed.

The server listens on `http://localhost:3000` (or `PORT`). By default it uses the
`pop-figure-api-main` database and `Pop` collection. Set `MONGODB_DATABASE` or
`MONGODB_COLLECTION` to override those defaults.

To commit every create, update, and delete to GitHub, also set these backend-only
variables:

```text
GITHUB_TOKEN=your-fine-grained-token
GITHUB_OWNER=ramojasm
GITHUB_REPO=pop-figure-api
GITHUB_FILE=data/figures.json
GITHUB_BRANCH=main
```

The token needs repository **Contents: Read and write** permission. If it is not set,
the API starts but write requests return an explicit configuration error.

Open `http://localhost:3000` in a browser to use the collection website. It can display,
search, add, and delete figures; changes are saved to MongoDB.

If you open `public/index.html` with VS Code Live Server instead, keep the API running
with `npm start`; the page will connect to `http://localhost:3000` automatically.
The API also allows the browser connection from Live Server.

Never commit `MONGODB_URI` or place it in frontend code. Export it in your shell
before starting the server, or configure it in your deployment provider's environment
settings.

## Endpoints

- `GET /health`
- `GET /figures?search=loki&category=Marvel&franchise=Loki&releaseYear=2021&page=1&limit=50`
- `GET /figures/:popNumber`
- `POST /figures`
- `PATCH /figures/:popNumber`
- `DELETE /figures/:popNumber`

Create and update requests use JSON. `imageUrl` is optional; when provided, it must be an
`http` or `https` URL and is displayed on the figure card. Optional `retailPrice` and
`resalePrice` values are shown when a card is expanded:

```json
{
  "popNumber": "898",
  "name": "President Loki",
  "releaseYear": 2021,
  "category": "Marvel",
  "franchise": "Loki",
  "imageUrl": "https://example.com/loki.png",
  "retailPrice": 14.99,
  "resalePrice": 35,
  "releaseYearEstimated": false
}
```

`popNumber` is a string so values such as `"06"` remain unchanged. The asterisk in `2023*` is represented by `releaseYearEstimated: true`.
